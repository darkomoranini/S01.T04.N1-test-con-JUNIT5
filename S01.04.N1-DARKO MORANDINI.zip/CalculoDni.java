
public class CalculoDni {

public	CalculoDni() {
	
}
	public String calculaLetraDni(int numeroDni) {
		String letras = "TRWAGMYPDXBNJZSQVHLCKE";
		String [] letrasArray = letras.split("");
		return letrasArray[numeroDni%23];
	}
}
