import static org.junit.jupiter.api.Assertions.*;

import java.util.stream.Stream;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.ValueSource;

public class CalculoDniTest {
	
	@ParameterizedTest
	//@ValueSource(ints = {29509717, 94359212, 86905155, 38181700, 30150347, 59339353, 53449026, 		//30638960, 89530445, 00275172 })
	@MethodSource("argumentsProvider")
	
	void test(String letra, int numero) {
		CalculoDni test1=new CalculoDni();
		String resultado=test1.calculaLetraDni(numero);
		assertEquals(letra, resultado);
	}
	static Stream<Arguments> argumentsProvider() {
        return Stream.of(
            Arguments.of("G", 29509717),
            Arguments.of("B", 94359212),
            Arguments.of("T", 86905155),
            Arguments.of("E", 38181700),
            Arguments.of("Q", 30150347),
            Arguments.of("K", 59339353),
            Arguments.of("V", 53449026),
            Arguments.of("V", 30638960),
            Arguments.of("R", 89530445),
            Arguments.of("S", 00275172)
        );
    }
}
