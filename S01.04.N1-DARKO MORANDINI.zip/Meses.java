import java.util.*;

public class Meses {
	ArrayList<String>listaMeses=new ArrayList<String>();
	
	public static void main(String [] Args) {	
	
	}		
	public  int addNombreMeses() {
		listaMeses.add("enero");
		listaMeses.add("febrero");
		listaMeses.add("marzo");
		listaMeses.add("abril");
		listaMeses.add("mayo");
		listaMeses.add("junio");
		listaMeses.add("julio");
		listaMeses.add("agosto");
		listaMeses.add("septiembre");
		listaMeses.add("octubre");
		listaMeses.add("noviembre");
		listaMeses.add("diciembre");	
		return listaMeses.size();
	}	
	public  String dameMes8() {
		addNombreMeses();
		return listaMeses.get(7);
	}
}
