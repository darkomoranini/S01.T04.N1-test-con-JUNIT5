import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class MesesTest {

	@Test
	void test() {
		Meses test1=new Meses();
		test1.addNombreMeses();
		assertEquals(12, 12);
	}
	@Test
	void test2() {
		Meses test2=new Meses();
		test2.dameMes8();
		assertEquals("agosto", test2.dameMes8());
	}
}
