import java.util.*;
public class Numeros {
	ArrayList<Integer>listaNumeros=new ArrayList<Integer>();;
	
	public Numeros() {
	}
	public ArrayList<Integer> getListaNumeros() {
		return listaNumeros;
	}
	
	public int metodoPrueba() throws ArrayIndexOutOfBoundsException {		
		
		int[] arr = {1, 2, 3};
		  int index = 3; 
		  	if(index>arr.length) {
				throw new ArrayIndexOutOfBoundsException(); 
			}
		  return arr[index];
		}	
	}
