import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class NumerosTest {

	@Test
	void test() {
		Numeros numeros=new Numeros();
		assertThrows(ArrayIndexOutOfBoundsException.class, () -> {
			numeros.metodoPrueba();
	    });
	}

}
